﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Go_Green_Group_Project.Models
{
    public abstract class Register
    {

        private string mName;
        private string mSurname;
        private string mEmail;
        private int mCellphone;
        private string mAddress;
        private string mPassword;

        public string Name
        {
            get { return mName; }
            set { mName = value; }
        }

        public string Surname
        {
            get { return mSurname; }
            set { mSurname = value; }
        }

        public int Cellphone
        {
            get { return mCellphone; }
            set { mCellphone = value; }
        }
        public string Email
        {
            get { return mEmail; }
            set { mEmail = value; }
        }

        public string Address
        {
            get { return mAddress; }
            set { mAddress = value; }
        }

        public string Password
        {
            get { return mPassword; }
            set { mPassword = value; }
        }
       

      


        

       
    }
}